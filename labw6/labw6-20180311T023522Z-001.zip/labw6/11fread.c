#include<stdio.h>
#include<stdlib.h>
#define MAX_LEN 100
void BlockReadWrite(FILE *fin,FILE *fout){
	int num;
	char buff(MAX_LEN+1);

	while(!foef(fin)){
		num=fread(buff,sizeof(char),MAX_LEN,fin);
		buff[num*sizeof(char)]='\0';

		printf("%s",buff);
		fwrite(buff,sizeof(char),num,fout);
	}
}
int main(){
	FILE *fin,*fout;
	if(fin=fopen("file11.txt","r+")){
		printf("cannot open file1!\n");
		exit(1);
	}
	else if(fin=fopen("file12.txt","w+")){
		printf("cannot open file2!\n");
		exit(1);
	}
	else{
	   	BlockReadWrite(fin,fout);
		fclose(fin);
		fclose(fout);
	}

	return 0;
}
