#include<stdio.h>
#include<stdlib.h>
#define MAX_LEN 80
enum {SUCCESS, FAIL};

typedef struct address{
	char name[20];
	char tel[11];
	char email[25];
}address_t;

int main(){
		address_t list[100];
	FILE *fp;
	char filename2[] = "file21.txt";
	int reval = SUCCESS;
	if ((fp = fopen(filename2, "wb")) == NULL)
	{
		printf("Cannot open %s.\n", filename2);
		reval = FAIL;
	}
	else{
		int i,n;
		for (i=0;i<10;i++){
			printf("name[%d]= ",i);
			fgets(list[i].name,20,stdin);
			
			printf("tel[%d]= ",i);
			fgets(list[i].tel,11,stdin);
			
			printf("email[%d]= ",i);
		   	fgets(list[i].email,25,stdin);
		}
			n=fwrite(list,sizeof(address_t),10,fp);
			printf("code: %d\n",n);
			fclose(fp);
	}
	
	if ((fp = fopen(filename2, "rb")) == NULL)
	{
		printf("Cannot open %s.\n", filename2);
		reval = FAIL;
	}
	else{
		int i,n;
		n= fread (list,sizeof(address_t),10,fp);
		printf("return code: %d",n);
		for (i=0;i<10;i++){
				printf("name[%d]= %s",i,list[i].name);
				printf("tel[%d]= %s",i,list[i].tel);
				printf("email[%d]= %s",i,list[i].email);
	  	}
	   	fclose(fp);
	}
	
	return 0;
}
