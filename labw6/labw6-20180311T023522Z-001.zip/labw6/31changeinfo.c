#include<stdio.h>
#include<stdlib.h>

enum {SUCCESS, FAIL, MAX_ELEM = 20};

typedef struct phoneaddress_t
{
	char name[20];
	char tel[11];
	char email[25];
} phoneaddress;

int main(){
	FILE *fp;
	phoneaddress *pa;
	int i,n,irc;
	int reval=SUCCESS;
	printf("read from 2nd to 3rd \n");

	if ((fp = fopen("phoneadd.txt", "r+b")) == NULL)
	{
		printf("Cannot open phoneadd.txt.\n");
		return FAIL;
	}
	pa=(phoneaddress*)malloc(2*sizeof(phoneaddress));
	if(pa==NULL){
		printf("memory allocation failed");
		reval=FAIL;
	}
	if(fseek(fp,1*sizeof(phoneaddress),SEEK_SET)!=0){
		printf("fseek failed");
		return FAIL;
	}
	irc=fread(pa,sizeof(phoneaddress),2,fp);
	for(i=0;i<2;i++){
		printf("%s-",pa[i].name);
		printf("%s-",pa[i].tel);
		printf("%s \n",pa[i].email);
	}
	fclose(fp);
	free(pa);
	return reval;
}
